# MUS2830

MUS2830 is Interactive Music course at Department of Musicology, University of Oslo.

The course is for bachelor students, and to provide them with an introduction to both analog and digital synthesis.

This year (2022), we teach Glicol and Pure Data for digital synthesis part.

This repo contains some acompanying files that I made for the course.
